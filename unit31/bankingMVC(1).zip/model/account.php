<?php
# An Account object corresponds to the columns in table savings

class Account {
  # declare two private fields: id and balance here
  
  
  
  # constructor with two arguments: id and balance

  
  
  # magic getter method: __get() 

  
  
   
  
}
?>
