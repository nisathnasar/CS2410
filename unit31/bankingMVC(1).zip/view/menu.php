<!DOCTYPE html>
<html>
<head>
<style>
ul {
    list-style-type: none;
    margin: 0;
    padding: 0;
}
</style>
</head>
<body>
		<h3>Menu</h3>
		<ul>
        <li class="navtop"><a href="?page=balance" >Balance</a></li>
		<li><a href="?page=withdraw" >Withdraw</a></li>
		<li><a href="?page=deposit" >Deposit</a></li>
		</ul>


<!-- Start of page-specific content. -->